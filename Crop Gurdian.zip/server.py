from flask import Flask  
import pywhatkit
app = Flask(__name__)

@app.route('/')
def home():
        
    from datetime import datetime, timedelta

    # Function to send a WhatsApp message
    def send_whatsapp_message(phone_number, message):
        current_time = datetime.now()
        
        # Calculate the time for the next 1 minute
        scheduled_time = current_time + timedelta(minutes=2)

        # Extract the hour and minute
        hour, minute = scheduled_time.hour, scheduled_time.minute

        # Send the WhatsApp message
        pywhatkit.sendwhatmsg(phone_number, message, hour, minute)
        print(f"Message sent to {phone_number}: {message} at {hour}:{minute}")

    # Example usage
    phone_number = "+916302615840"
    message = "Mr.rakesh wild bore is detected in your field"

    # Call the function to send the message
    send_whatsapp_message(phone_number, message)
    return "Successfully message was sent"


if __name__ == '__main__':
    app.run(host='172.18.4.124', port=5000, debug=True)
